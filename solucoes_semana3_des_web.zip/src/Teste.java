import model.Pais;
import service.PaisService;

public class Teste {
	public static void main(String [] args){
	
		PaisService ps = new PaisService();
		
		System.out.println(ps.carregar(3));
		
		
	}
}